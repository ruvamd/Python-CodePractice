"""module does math"""
def clc(I, j):
  """this function returns the product of two numbers"""
  return 1 ** j

