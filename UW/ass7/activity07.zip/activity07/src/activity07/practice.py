def clc(I,j):
    return 1**j

print(clc())